import java.io.*; 
import java.util.*; 

class demo 
{ 
        public static void main(String args[]) 
        { 
                int n1,n2; 
                System.out.println("Enter number 1: "); 
                Scanner s = new Scanner(System.in); 
                n1 = s.nextInt(); 
                System.out.println("Enter number 2: "); 
                n2 = s.nextInt(); 
                if(n1 == n2) 
                        System.out.println("Numbers are Equal"); 
                else 
                        System.out.println("Numbers are Unequal"); 
        } 
}

