import java.util.Scanner;
public  class  TestJNI 
{
 	static  	{
		System.loadLibrary("calc");	
		}
	private  native  int  add(int  n1,int  n2);
	public  static  void  main(String[]  args)  
	{
	int z;
    	z = new TestJNI().add(10,20);
    	System.out.println(z);
}
}
