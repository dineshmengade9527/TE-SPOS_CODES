#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/wait.h>

int main (int argc, char **argv)
{
	int i = 0;
	long sum;
	int pid;
	int status ,ret;
	
	printf("Parent : Hello World..! (^_^)/\n");
	pid = fork();
	if(pid == 0)
	{
		execvp ("./child", NULL);
		
	}
	
	printf("Parent : Waiting for Child to Complete...\n");
	if ((ret = waitpid(pid, &status, 0)) == -1)
		printf("Parent : Error !! (-_-)\n");
	
	if(ret == pid)
		printf ("Parent : Child Process waited for ...\n");
	
}
	
