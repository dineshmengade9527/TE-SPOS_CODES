while :
do

echo ***********MENU***********
echo
echo 1.Process information
echo 2.Send Process in Background
echo 3.Kill the process
echo 4.Change niceness of Process
echo 5.Exit!
echo
echo Enter a choice

read ch
case $ch in

1)echo
ps -l
 ;;

2)echo Enter process to be sent in background
read cmd
$cmd &

;;
3)ps
echo Enter PID of process to be killed!
read process
kill -9 $process
echo Process Killed!

;;
4)echo enter niceness of command
ps -l
read niceness
echo Enter cmd
read cmd
nice -n $niceness $cmd
ps -l
 
;;
5) exit;;
esac

done

#
#$ chmod +x ShellScript.sh
#$ ./ShellScript.sh


